package application;

public class IntPair {
	private int i,j;
	public IntPair(int i, int j){
		this.i=i;
		this.j=j;
	}
	public int getI()
	{
		return i;
	}
	public int getJ(){
		return j;
	}
}